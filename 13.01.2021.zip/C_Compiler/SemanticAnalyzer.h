#pragma once
#define MAX_SYMBOL_NAME 255
#define MAX_DATATYPE_NAME 50

enum IdentifierScope { Local = 0, Global};

typedef struct symTableEntry {
	char symbolName[MAX_SYMBOL_NAME];
	char dataType[MAX_DATATYPE_NAME];
	IdentifierScope symbolScope;
	char contextName[MAX_SYMBOL_NAME];
};
